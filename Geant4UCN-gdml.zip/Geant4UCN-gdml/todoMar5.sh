ln -sf Gassner/Gassner+Chambers+Y.gdml test.gdml

for i in 0 ; do
 echo $i > DetectorDIFFUSION.txt
 echo $i > CopperDIFFUSION.txt
 for ii in 0.00001 0.00005 0.0001 0.00015 0.0002 0.0003; do
  echo $ii > DetectorETA.txt
  echo $ii > CopperETA.txt
  neV=10
  until [  $neV -gt 150 ]; do
   sed "s/gunEnergyneV 10/gunEnergyneV ${neV}/g" default.UCNgdml.mac > UCNgdml.mac
   #grep neV UCNgdml.mac
   ./UCNgdml > myUCNgdml.log
   myDirName=$(sed 's/\./p/g' <<<  "Mar5E${ii}D${i}e${neV}neV")
   #echo $myDirName
   #cat DetectorETA.txt
   #cat DetectorDIFFUSION.txt
   mkdir $myDirName
   mv my*  $myDirName
   let neV+=20
   #echo neV $neV 
  done
  #echo eta $ii
 done	 
 #echo diff $i
done

