# sed 's/gunEnergyneV 10/gunEnergyneV 100/g;'  UCNgdml.default.mac > UCNgdml.100neV.mac
ln -sf Gassner/Gassner180deg.gdml test.gdml

rm UCNgdml.mac

ln -sf UCNgdml.10neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_10neV
cp my* Gassner_10neV

ln -sf UCNgdml.20neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_20neV
cp my* Gassner_20neV

ln -sf UCNgdml.30neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_30neV
cp my* Gassner_30neV

ln -sf UCNgdml.40neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_40neV
cp my* Gassner_40neV

ln -sf UCNgdml.50neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_50neV
cp my* Gassner_50neV

ln -sf UCNgdml.60neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_60neV
cp my* Gassner_60neV

ln -sf UCNgdml.70neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_70neV
cp my* Gassner_70neV

ln -sf UCNgdml.80neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_80neV
cp my* Gassner_80neV

ln -sf UCNgdml.90neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_90neV
cp my* Gassner_90neV

ln -sf UCNgdml.100neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_100neV
cp my* Gassner_100neV

ln -sf UCNgdml.110neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_110neV
cp my* Gassner_110neV

ln -sf UCNgdml.120neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_120neV
cp my* Gassner_120neV

ln -sf UCNgdml.130neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_130neV
cp my* Gassner_130neV

ln -sf UCNgdml.140neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_140neV
cp my* Gassner_140neV

ln -sf UCNgdml.150neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_150neV
cp my* Gassner_150neV
# sed 's/gunEnergyneV 10/gunEnergyneV 100/g;'  UCNgdml.default.mac > UCNgdml.100neV.mac
ln -sf Gassner/Gassner180deg.gdml test.gdml

rm UCNgdml.mac

ln -sf UCNgdml.160neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_160neV
cp my* Gassner_160neV

ln -sf UCNgdml.170neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_170neV
cp my* Gassner_170neV

ln -sf UCNgdml.180neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_180neV
cp my* Gassner_180neV

ln -sf UCNgdml.190neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_190neV
cp my* Gassner_190neV

ln -sf UCNgdml.10neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_10neV
cp my* ETA5Gassner_10neV

ln -sf UCNgdml.20neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_20neV
cp my* ETA5Gassner_20neV

ln -sf UCNgdml.30neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_30neV
cp my* ETA5Gassner_30neV

ln -sf UCNgdml.40neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_40neV
cp my* ETA5Gassner_40neV

ln -sf UCNgdml.50neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_50neV
cp my* ETA5Gassner_50neV

ln -sf UCNgdml.60neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_60neV
cp my* ETA5Gassner_60neV

ln -sf UCNgdml.70neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_70neV
cp my* ETA5Gassner_70neV

ln -sf UCNgdml.80neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_80neV
cp my* ETA5Gassner_80neV

ln -sf UCNgdml.90neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_90neV
cp my* ETA5Gassner_90neV

ln -sf UCNgdml.100neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_100neV
cp my* ETA5Gassner_100neV

ln -sf UCNgdml.110neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_110neV
cp my* ETA5Gassner_110neV

ln -sf UCNgdml.120neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_120neV
cp my* ETA5Gassner_120neV

ln -sf UCNgdml.130neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_130neV
cp my* ETA5Gassner_130neV

ln -sf UCNgdml.140neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_140neV
cp my* ETA5Gassner_140neV

ln -sf UCNgdml.150neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_150neV
cp my* ETA5Gassner_150neV

ln -sf UCNgdml.160neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_160neV
cp my* ETA5Gassner_160neV

ln -sf UCNgdml.170neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_170neV
cp my* ETA5Gassner_170neV

ln -sf UCNgdml.180neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_180neV
cp my* ETA5Gassner_180neV

ln -sf UCNgdml.190neV.mac UCNgdml.mac
./UCNgdmlETA5LOSS0 > myUCNgdml.log
mkdir ETA5Gassner_190neV
cp my* ETA5Gassner_190neV
