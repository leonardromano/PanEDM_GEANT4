//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
// $Id: UCNPrimaryGeneratorMessenger.cc,v 1.1.1.1 2004/10/25 12:36:47 kuzniak Exp $
// GEANT4 tag $Name:  $
//
//   changed for UCN 9.9.04 peter fierlinger

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

#include "UCNPrimaryGeneratorMessenger.hh"
#include "UCNPrimaryGeneratorAction.hh"

#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

UCNPrimaryGeneratorMessenger::UCNPrimaryGeneratorMessenger(UCNPrimaryGeneratorAction* UCNGun)
  : UCNAction(UCNGun)
{ 
  G4cout << "create messenger for the UCN Primary Generator class " << G4endl;
  gunDirectory = new G4UIdirectory("/gun/");
  gunDirectory->SetGuidance("Particle Gun control commands.");
  
  setGunPositionCmd = new G4UIcmdWith3VectorAndUnit("/gun/gunPosition",this);
  setGunPositionCmd->SetGuidance(" Set coord. of the gun position.");
  setGunPositionCmd->SetParameterName("X","Y","Z",true,true);
  setGunPositionCmd->SetDefaultUnit("mm");
  //setGunPositionCmd->SetDefaultValue(0.0*mm, 0.0*mm, 0.0*mm) ; 
  
  setxGunDirectionCmd = new G4UIcmdWithADouble("/gun/xGunDirection",this);
  setxGunDirectionCmd->SetGuidance(" Set x coord. of the gun direction.");
  setxGunDirectionCmd->SetParameterName("xv",true);
  setxGunDirectionCmd->SetDefaultValue(0.0) ; 
  
  setyGunDirectionCmd = new G4UIcmdWithADouble("/gun/yGunDirection",this);
  setyGunDirectionCmd->SetGuidance(" Set y coord. of the gun direction.");
  setyGunDirectionCmd->SetParameterName("yv",true);
  setyGunDirectionCmd->SetDefaultValue(0.0) ; 
  
  setzGunDirectionCmd = new G4UIcmdWithADouble("/gun/zGunDirection",this);
  setzGunDirectionCmd->SetGuidance(" Set z coord. of the gun direction.");
  setzGunDirectionCmd->SetParameterName("zv",true);
  setzGunDirectionCmd->SetDefaultValue(0.0) ;
  
  setGunEnergy_neVCmd = new G4UIcmdWithADouble("/gun/gunEnergyneV",this);
  setGunEnergy_neVCmd->SetGuidance(" Set energy of the gun in neV");
  setGunEnergy_neVCmd->SetParameterName("e",true);
  setGunEnergy_neVCmd->SetDefaultValue(0.0) ; 
  
  setGunDirectionRangeCmd = new G4UIcmdWithADouble("/gun/gunDirectionRange",this);
  setGunDirectionRangeCmd->SetGuidance(" Set gun direction range (centered around the gun direction)");
  setGunDirectionRangeCmd->SetParameterName("xv",true);
  setGunDirectionRangeCmd->SetDefaultValue(0.0) ; 
  
  setGunMaxRadCmd = new G4UIcmdWithADoubleAndUnit("/gun/gunMaxRad",this);
  setGunMaxRadCmd->SetGuidance(" Set radius of the gun.");
  setGunMaxRadCmd->SetParameterName("zv",true);
  setGunMaxRadCmd->SetDefaultValue(0.0*mm) ; 
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

UCNPrimaryGeneratorMessenger::~UCNPrimaryGeneratorMessenger()
{
  delete gunDirectory;
  delete setGunPositionCmd;
  delete setxGunDirectionCmd;
  delete setyGunDirectionCmd;
  delete setzGunDirectionCmd;
  delete setGunEnergy_neVCmd;
  delete setGunDirectionRangeCmd;
  delete setGunMaxRadCmd;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

void UCNPrimaryGeneratorMessenger::SetNewValue(G4UIcommand * command,G4String newValue)
{ 
  if( command == setGunPositionCmd)
   { UCNAction->SetGunPosition(setGunPositionCmd->GetNew3VectorValue(newValue));}
  if( command == setxGunDirectionCmd)
   { UCNAction->SetxGunDirection(setxGunDirectionCmd->GetNewDoubleValue(newValue));}
  if( command == setyGunDirectionCmd)
   { UCNAction->SetyGunDirection(setyGunDirectionCmd->GetNewDoubleValue(newValue));}
  if( command == setzGunDirectionCmd)
   { UCNAction->SetzGunDirection(setzGunDirectionCmd->GetNewDoubleValue(newValue));}
  if( command == setGunEnergy_neVCmd)
   { UCNAction->SetGunEnergy_neV(setGunEnergy_neVCmd->GetNewDoubleValue(newValue));}
  if( command == setGunDirectionRangeCmd)
   { UCNAction->SetGunDirectionRange(setGunDirectionRangeCmd->GetNewDoubleValue(newValue));}
  if( command == setGunMaxRadCmd)
   { UCNAction->SetGunMaxRad(setGunMaxRadCmd->GetNewDoubleValue(newValue));}
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

