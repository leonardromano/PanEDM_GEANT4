//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//
// 

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "UCNPrimaryGeneratorAction.hh"

#include "UCNDetectorConstruction.hh"
#include "UCNPrimaryGeneratorMessenger.hh"

#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "Randomize.hh"

#include <fstream>
std::ofstream myGunFile("myGunFile.txt");
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

UCNPrimaryGeneratorAction::UCNPrimaryGeneratorAction(void)
    : gunPosition(0.000*mm,0.0*mm,0.000*mm)// central point, approx 4mm outside entrance pipe
    ,xGunDirection(1.),yGunDirection(0.),zGunDirection(0.),gunEnergy_neV(10.),gunDirectionRange(0.5),gunMaxRad(23.*mm) 
{
  G4int n_particle = 1;
  particleGun  = new G4ParticleGun(n_particle);

  // create a messenger for this class
  //
  gunMessenger = new UCNPrimaryGeneratorMessenger(this);
  
  G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
  G4ParticleDefinition* particle = particleTable->FindParticle("neutron");

  particleGun->SetParticleDefinition(particle);
  eventID = 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

UCNPrimaryGeneratorAction::~UCNPrimaryGeneratorAction()
{
  delete particleGun;
  delete gunMessenger;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void UCNPrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
  //this function is called at the begining of event
  //

  //thePrimaryParticleName = particleGun->GetParticleDefinition()->GetParticleName() ;
  //G4double n_energy = 10.; // neV
  //G4double massnew = 1.674927e-27;     //neutronmasse in kg
    
  G4double px=0.0,py=0.0,pz=0.0 ;
  //start - similar for ALL particles
  G4ThreeVector spin(0,1,0);
  G4ThreeVector xaxis(1,0,0);
  G4ThreeVector yaxis(0,1,0);

  G4double gunDirectionNorm = sqrt(xGunDirection*xGunDirection+yGunDirection*yGunDirection+zGunDirection*zGunDirection);
  G4double theta0   = acos(yGunDirection/gunDirectionNorm);  
  G4double phi0 = 0;
  if (zGunDirection<0.){phi0=acos(-1.);};
  if (zGunDirection!=0 && xGunDirection!=0){phi0= atan(xGunDirection/zGunDirection);}; 
  //end - similar for ALL particles 


  G4double xz1 = G4UniformRand();
  G4double y1  = G4UniformRand();
  G4double radius1 = (xz1*xz1+y1*y1);

 while (radius1 > 1.)
  {
  xz1 = G4UniformRand();
  y1  = G4UniformRand();
  radius1 = (xz1*xz1+y1*y1);
  } 
  
  G4double signXZ  = G4UniformRand();
  while (signXZ == 0.5)
  {signXZ  = G4UniformRand();}
  if (signXZ > 0.5){xz1=-xz1;};
  
  G4double signY   = G4UniformRand();
  while (signY == 0.5)
  {signY  = G4UniformRand();}
  if (signY  > 0.5){y1 =-y1 ;};
  
  G4ThreeVector gunPositionShift(xz1*gunMaxRad,y1*gunMaxRad,0.);  
  if (phi0!=0){gunPositionShift.rotate(phi0,yaxis);};
  //if (phi0!=0){G4ThreeVector gunPositionShift(xz1*gunMaxRad,y1*gunMaxRad,0.);}
  //else{G4ThreeVector gunPositionShift(xz1*cos(phi0)*gunMaxRad,y1*gunMaxRad,xz1*sin(phi0)*gunMaxRad);};

  particleGun->SetParticlePosition(gunPosition + gunPositionShift);

 /* 
  //45 degree rotation ... sin or cos at (0.25*pi) = 0.70710678118
  particleGun->SetParticlePosition(G4ThreeVector(xGunPosition+xz1*0.70710678118*gunMaxRad,
                                                 yGunPosition+y1*gunMaxRad,
						 zGunPosition+xz1*0.70710678118*gunMaxRad));
  */

  // double time = 0.3; // s
  
  //particleGun->SetParticleTime(time);
  particleGun->SetParticlePolarization(spin);
  
  G4double particleEnergy = gunEnergy_neV*1e-9*eV;
  //G4double particleEnergy = G4UniformRand()*1e-7*eV;
  particleGun->SetParticleEnergy(particleEnergy);

  
 // G4ThreeVector momentum(xGunDirection/gunDirectionNorm,yGunDirection/gunDirectionNorm,zGunDirection/gunDirectionNorm);
  G4double theta   = gunDirectionRange*pi*(G4UniformRand()-0.5);  //  gunDirectionRange * [- 0.5 pi, 0.5 pi]
  G4double phi = 2*pi*(G4UniformRand()-0.5);  //  [- pi, pi]

  px = sin(theta)*cos(phi);
  py = cos(theta); 
  pz = -sin(theta)*sin(phi);
  
 
  //rotate by phi0, theta0
  G4ThreeVector momentum(px,py,pz);
  momentum.rotate(-theta0,xaxis);
  momentum.rotate(phi0,yaxis);

  myGunFile << gunPositionShift << " " 
//	    << gunPositionShiftNew << " "
//	    << gunPositionShiftOld << " "
	    << px << " "<< py << " "<< pz << " " << momentum 
//	    << theta0  << " "<< phi0 << " "
	    << theta  << " "<< phi << " "<< particleEnergy << std::endl;

  particleGun->SetParticleMomentumDirection(momentum);

  particleGun->GeneratePrimaryVertex(anEvent);
  anEvent->SetEventID(eventID);
  eventID += 1;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void UCNPrimaryGeneratorAction::SetGunPosition(G4ThreeVector xyz)
{
  gunPosition = xyz ;
  G4cout << " Coordinates of the gun position = " << gunPosition/mm <<
            " mm." << G4endl;
}
void UCNPrimaryGeneratorAction::SetxGunDirection(G4double x)
{
  xGunDirection = x ;
  G4cout << " X coordinate of the gun direction = " << xGunDirection << G4endl;
}

void UCNPrimaryGeneratorAction::SetyGunDirection(G4double y)
{
  yGunDirection = y ;
  G4cout << " Y coordinate of the gun direction = " << yGunDirection << G4endl;
}
void UCNPrimaryGeneratorAction::SetzGunDirection(G4double z)
{
  zGunDirection = z ;
  G4cout << " Z coordinate of the gun direction = " << zGunDirection << G4endl;
}
//
void UCNPrimaryGeneratorAction::SetGunEnergy_neV(G4double e)
{
  gunEnergy_neV = e ;
  G4cout << " Energy the gun = " << gunEnergy_neV << " neV" << G4endl;
}
//
void UCNPrimaryGeneratorAction::SetGunDirectionRange(G4double x)
{
  gunDirectionRange = x ;
  G4cout << " Gun direction range = " << gunDirectionRange << " (1 is a half sphere centered around the gun direction)" << G4endl;
}
//
void UCNPrimaryGeneratorAction::SetGunMaxRad(G4double r)
{
  gunMaxRad = r ;
  G4cout << " Radius of the gun = " << gunMaxRad/mm <<
            " mm." << G4endl;
}
