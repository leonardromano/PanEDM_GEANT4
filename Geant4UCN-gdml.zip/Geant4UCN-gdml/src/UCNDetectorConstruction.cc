//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//
// 

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "UCNDetectorConstruction.hh"

#include "G4Material.hh"
#include "G4NistManager.hh"

#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"

#include "G4ios.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"

#include "G4UserLimits.hh"

#include "UCNField.hh"

#include "G4RunManager.hh"
// GDML parser include
//
#include "G4GDMLParser.hh"

#include <fstream>
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

UCNDetectorConstruction::UCNDetectorConstruction()
  : Vacuum(0), field(0), etaNI(1e-5), diffusionNI(0.01), etaCU(1e-5), diffusionCU(0.01),etaNiRough(1e-5), diffusionNiRough(0.01)
{
  std::ifstream myEtaFile;
  myEtaFile.open("DetectorETA.txt");
  myEtaFile >> etaNI;
  myEtaFile.close();
  std::ifstream myDiffusionFile;
  myDiffusionFile.open("DetectorDIFFUSION.txt");
  myDiffusionFile >> diffusionNI;
  myDiffusionFile.close();
  std::ifstream roughNiEtaFile;
  roughNiEtaFile.open("RoughNiETA.txt");
  roughNiEtaFile >> etaNiRough;
  roughNiEtaFile.close();
  std::ifstream roughNiDiffusionFile;
  roughNiDiffusionFile.open("RoughNiDIFFUSION.txt");
  roughNiDiffusionFile >> diffusionNiRough;
  roughNiDiffusionFile.close();
  std::ifstream copperEtaFile;
  copperEtaFile.open("CopperETA.txt");
  copperEtaFile >> etaCU;
  copperEtaFile.close();
  std::ifstream copperDiffusionFile;
  copperDiffusionFile.open("CopperDIFFUSION.txt");
  copperDiffusionFile >> diffusionCU;
  copperDiffusionFile.close();
  
  //G4double expHall_x = 5.0*m;
  //G4double expHall_y = 5.0*m;
  //G4double expHall_z = 5.0*m;
  
  // materials
  DefineMaterials();

  fReadFile ="test.gdml";

  // ensure the global field is initialized
  field = new UCNField();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

UCNDetectorConstruction::~UCNDetectorConstruction()
{
  delete field;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void UCNDetectorConstruction::DefineMaterials()
{
  #include "UCNDetectorMaterials.icc"
  //G4NistManager* nistMan = G4NistManager::Instance();
  //G4Material* Vacuum = nistMan->FindOrBuildMaterial("G4_Galactic");
  
  G4cout << "DefineMaterials: loss coefficient W/V (set via DetectorETA.txt) = " << etaNI << " diffuse scattering probability (set via DetectorDIFFUSION.txt) = " << diffusionNI << G4endl;
  G4cout << "DefineMaterials: loss coefficient W/V (set via CopperETA.txt) = " << etaCU << " diffuse scattering probability (set via CopperDIFFUSION.txt) = " << diffusionCU << G4endl;
  G4cout <<  "reading UCNDetectorMaterials.icc" << G4endl;
  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* UCNDetectorConstruction::Construct()
{
  G4VPhysicalVolume* fWorldPhysVol;
    // **** LOOK HERE*** FOR READING GDML FILES
    //
    // ACTIVATING OVERLAP CHECK when read volumes are placed.
    // Can take long time in case of complex geometries
    //
#ifdef GDML_OverlapCheck
    parser.SetOverlapCheck(true);
#endif
    parser.Read(fReadFile);

    // READING GDML FILES OPTION: 2nd Boolean argument "Validate".
    // Flag to "false" disables check with the Schema when reading GDML file.
    // See the GDML Documentation for more information.
    //
    // parser.Read(fReadFile,false);
     
    // Prints the material information
    //
    G4cout << *(G4Material::GetMaterialTable() ) << G4endl;
         
    // Giving World Physical Volume from GDML Parser
    //
  fWorldPhysVol = parser.GetWorldVolume();     

   G4double maxStep = 0.05*mm;
   G4double maxTime = 41.*s;
   G4UserLimits* stepLimit = new G4UserLimits(maxStep,DBL_MAX,maxTime);
   fWorldPhysVol->GetLogicalVolume()->SetUserLimits(stepLimit);

//--------- Visualization attributes -------------------------------
  // Set Visualization attributes to world
  //G4VisAttributes* Red        = new G4VisAttributes( G4Colour(255/255. ,0/255.   ,0/255.   ));
  G4VisAttributes* Yellow     = new G4VisAttributes( G4Colour(255/255. ,255/255. ,0/255.   ));
  G4VisAttributes* LightBleu  = new G4VisAttributes( G4Colour(0/255.   ,204/255. ,204/255. ));
  //LightBleu->SetForceSolid(true);
  G4VisAttributes* LightGreen = new G4VisAttributes( G4Colour(153/255. ,255/255. ,153/255. ));
  G4VisAttributes* White = new G4VisAttributes( G4Colour(1.0,1.0,1.0));
  //fWorldPhysVol->GetLogicalVolume()->SetVisAttributes(White);
  fWorldPhysVol->GetLogicalVolume()-> SetVisAttributes(G4VisAttributes::Invisible); 
  G4LogicalVolumeStore* MyGDML = G4LogicalVolumeStore::GetInstance(); 
  MyGDML->GetVolume("Filter1")->SetVisAttributes(LightBleu);
  MyGDML->GetVolume("Filter2")->SetVisAttributes(LightBleu);
  //MyGDML->GetVolume("Y180copperTop")->SetVisAttributes(LightGreen);
  /*
  MyGDML->GetVolume("Detector1a")->SetVisAttributes(LightGreen);
  MyGDML->GetVolume("Detector2a")->SetVisAttributes(LightGreen);
  MyGDML->GetVolume("detektor-1.STL")->SetVisAttributes(LightGreen);
  MyGDML->GetVolume("detektor-2.STL")->SetVisAttributes(LightGreen);
  MyGDML->GetVolume("adapter.STL")->SetVisAttributes(LightBleu);
  MyGDML->GetVolume("copper.STL")->SetVisAttributes(LightBleu);
  MyGDML->GetVolume("senkrecht.STL")->SetVisAttributes(LightBleu);
  MyGDML->GetVolume("Y_unten-1.STL")->SetVisAttributes(LightBleu);
  MyGDML->GetVolume("Y_unten-2.STL")->SetVisAttributes(LightBleu);
  MyGDML->GetVolume("quelle.STL")->SetVisAttributes(Yellow);
  */
  //ConstructCalorimeter();
  return fWorldPhysVol;
}

////////////////////////////////////////////////////////////////////////////
// ----------------------------------------------------------------------------
//
// SetReadFile
//
void UCNDetectorConstruction::SetReadFile( const G4String& File )
{
  fReadFile=File;
  writingChoice=0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
