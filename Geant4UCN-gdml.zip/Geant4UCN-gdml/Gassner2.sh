# sed 's/gunEnergyneV 10/gunEnergyneV 100/g;'  UCNgdml.default.mac > UCNgdml.100neV.mac
ln -sf Gassner/Gassner180deg.gdml test.gdml

rm UCNgdml.mac

ln -sf UCNgdml.160neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_160neV
cp my* Gassner_160neV

ln -sf UCNgdml.170neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_170neV
cp my* Gassner_170neV

ln -sf UCNgdml.180neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_180neV
cp my* Gassner_180neV

ln -sf UCNgdml.190neV.mac UCNgdml.mac
./UCNgdml > myUCNgdml.log
mkdir Gassner_190neV
cp my* Gassner_190neV
