//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// --------------------------------------------------------------
//      GEANT 4 - UCN with gdml input
// --------------------------------------------------------------
// Comments
//     Peter & Katharina Fierlinger, November 2018  
// --------------------------------------------------------------
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "G4RunManager.hh"
#include "G4UImanager.hh"

#include "G4UIterminal.hh"
#include "G4UItcsh.hh"

#include "Randomize.hh"

#include "UCNPhysicsList.hh"
#include "UCNDetectorConstruction.hh"
#include "UCNPrimaryGeneratorAction.hh"

//T #include "UCNFieldSetup.hh"
//T #include "F02RunAction.hh"
//T #include "F02EventAction.hh"
//T #include "F02SteppingAction.hh"
//T #include "UCNSaveToFile.hh"

#include "G4SteppingVerbose.hh"

//Uncomment next two lines for a terminal version 
//#undef G4VIS_USE
//#undef G4UI_USE
#define GDML_OverlapCheck 1
//#undef GDML_OverlapCheck

#ifdef G4VIS_USE
#include "G4VisExecutive.hh"
#endif

#ifdef G4UI_USE
#include "G4UIExecutive.hh"
#endif

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

int main(int argc,char** argv)
{
  G4int seed = 715000034;
  //if (argc  > 2) seed = atoi(argv[argc-1]);

  // Choose the Random engine
  //
  CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);
  CLHEP::HepRandom::setTheSeed(seed);
  
  // User Verbose output class
  //
  G4VSteppingVerbose::SetInstance(new G4SteppingVerbose());

  // Construct the default run manager
  //
  G4RunManager * runManager = new G4RunManager;

  // create a class where all results from the calculation are sent to
  //T UCNSaveToFile * savetofile = new UCNSaveToFile;

  // Construct the helper class to manage the electric field & 
  //  the parameters for the propagation of particles in it.

  //T UCNFieldSetup* field = new UCNFieldSetup() ;

  // Set mandatory initialization classes
  //
  runManager->SetUserInitialization(new UCNDetectorConstruction());
  //
  runManager->SetUserInitialization(new UCNPhysicsList());
   
#ifdef G4VIS_USE

  // visualization manager

  G4VisManager* visManager = new G4VisExecutive();
  visManager->Initialize();

#endif
    
  // Set mandatory user action class
  //
  runManager->SetUserAction(new UCNPrimaryGeneratorAction());
  //T  F02RunAction* runAction = new F02RunAction;
  //T  runManager->SetUserAction(runAction);
  //T 
  //T  F02EventAction* eventAction = new F02EventAction(runAction);
  //T  runManager->SetUserAction(eventAction);
  //T 
  //T  F02SteppingAction* steppingAction = new F02SteppingAction();
  //T  runManager->SetUserAction(steppingAction);

  // Initialize G4 kernel, physics tables ...
  // gdml read also here
  runManager->Initialize();
  
#ifdef G4UI_USE
  // Get the pointer to the User Interface manager
  //
  G4UImanager* UImanager = G4UImanager::GetUIpointer();
#endif

 // interactive mode : define UI session
  G4String command = "/control/execute ";
#ifdef G4VIS_USE 
  G4String fileName = "UCNgdml.vis.mac";
#else
  G4String fileName = "UCNgdml.mac";
#endif
  if (argc!=1)   // batch mode
    {
      fileName = argv[1];
    }
#ifdef G4UI_USE
  G4UIExecutive* ui = new G4UIExecutive(argc, argv);
#ifdef G4VIS_USE 
  UImanager->ApplyCommand(command+fileName);    
#endif
  ui->SessionStart();
  delete ui;
#else
  G4UImanager::GetUIpointer()->ExecuteMacroFile(fileName);
#endif
  
     
  // job termination

#ifdef G4VIS_USE
  delete visManager;
#endif
  //T delete field;
  //T delete savetofile;
  delete runManager;

  return 0;
}

