//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//
// 

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#ifndef UCNPrimaryGeneratorAction_h
#define UCNPrimaryGeneratorAction_h 1

#include "globals.hh"
#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4ThreeVector.hh"


class G4Event;
class G4ParticleGun;
class UCNPrimaryGeneratorMessenger;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class UCNPrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction
{
public:

  UCNPrimaryGeneratorAction(void);    
  virtual ~UCNPrimaryGeneratorAction();

  void GeneratePrimaries(G4Event*);
  void SetGunPosition(G4ThreeVector xyz) ;
  void SetxGunDirection(G4double x) ;
  void SetyGunDirection(G4double y) ;
  void SetzGunDirection(G4double z) ;
  void SetGunEnergy_neV(G4double e) ;
  void SetGunDirectionRange(G4double x) ;
  void SetGunMaxRad(G4double r) ;

private:

  G4ParticleGun* particleGun;
  UCNPrimaryGeneratorMessenger* gunMessenger; // messenger of this class
  G4ThreeVector gunPosition;
  G4double xGunDirection,yGunDirection,zGunDirection;
  G4double gunEnergy_neV,gunDirectionRange,gunMaxRad;
  int eventID;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
